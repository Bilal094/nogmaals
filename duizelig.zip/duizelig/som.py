i = 50
e = 51
while i <= 1100:
    print(i)
    i=i+e
    e=e+1