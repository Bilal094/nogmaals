i = 22

while i <= 48:
    print(i)
    i=i+2
input('')