i = 23
x = 11

while i >= 12:
    print(str(i) +' PM')
    i=i-1
while x >= 00:
    print(str(x) +' AM')
    x=x-1