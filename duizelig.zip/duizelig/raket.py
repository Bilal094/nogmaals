from time import sleep
i = 30

while i >= 1:
    print(i)
    sleep(1)
    i=i-1
print('Raket is gelanceerd')